package com.example.otodu.Controller;

import com.example.otodu.Koneksi.PenggunaKoneksi;
import com.example.otodu.Utils.UbahHalaman;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController {

    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private Button loginBtn;
    @FXML private Button registerBtn;
    @FXML private Label loginMessage;


    @FXML
    public void initialize(){
        loginBtn.setOnAction(e -> {
            loginBtnOnAction(e);
        });

        registerBtn.setOnAction(e -> {
            UbahHalaman.switchScene(e, "Registrasi.fxml");
        });
    }

    public void loginBtnOnAction(ActionEvent event){
//        String username = emailField.getText();
//        String password = passwordField.getText();

        String username = "dl@gmail.com";
        String password = "tes";

        if(!username.isBlank() && !password.isBlank()){
            if(PenggunaKoneksi.verifLogin(username, password)){
                UbahHalaman.switchScene(event, "NLPDashboard.fxml");
            }
            else
                loginMessage.setText("Username atau Password salah");
        }else{
            loginMessage.setText("Username dan Password tidak boleh kosong!");
        }
    }
}
