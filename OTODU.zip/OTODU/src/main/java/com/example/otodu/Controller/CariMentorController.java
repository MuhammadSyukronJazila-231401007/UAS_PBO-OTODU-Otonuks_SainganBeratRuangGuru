package com.example.otodu.Controller;

import com.example.otodu.Model.Mentor;
import com.example.otodu.Utils.UbahHalaman;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.ArrayList;
import java.util.List;

public class CariMentorController {

    @FXML private VBox mentorCardContainer;
    @FXML private Label nlpLabel;

    public void tampilkanDaftarMentor(List<Mentor> mentorList) {
        mentorCardContainer.getChildren().clear();
        for (Mentor mentor : mentorList) {
            VBox card = buatCardMentor(mentor);
            mentorCardContainer.getChildren().add(card);
        }
    }

    @FXML
    public void initialize() {
        List<Mentor> data = new ArrayList<>();
        data.add(new Mentor(12,"Emilia Antoine", "emilia@mail.com", "+62812", "Bandung", "pass", "Mentor", 100));
        data.add(new Mentor(14, "Jeanette", "jean@mail.com", "+62899", "Jakarta", "pass", "Mentor", 80));

        tampilkanDaftarMentor(data);
        nlpLabel.setOnMouseClicked(e -> {
            UbahHalaman.switchScene(e,"NLPDashboard.fxml");
        });
    }

    private VBox buatCardMentor(Mentor mentor) {
        VBox card = new VBox(8);
        card.setPadding(new Insets(15));
        card.setSpacing(8);
        card.setStyle("-fx-background-color: white; -fx-border-color: #E0E0E0; -fx-border-width: 1; -fx-background-radius: 6;");
        card.setPrefWidth(600);

        Label nama = new Label(mentor.getNama());
        nama.setStyle("-fx-font-size: 16px; -fx-text-fill: #495DA3; -fx-font-weight: bold;");

        Label email = new Label(mentor.getEmail());
        email.setStyle("-fx-font-size: 13px;");

        Label nomor = new Label("No: " + mentor.getNomor());
        nomor.setStyle("-fx-font-size: 13px;");

        Label kota = new Label(mentor.getKota());
        kota.setStyle("-fx-font-size: 12px; -fx-background-color: #E1F0FF; -fx-border-color: #007BFF; -fx-padding: 4 10 4 10;");

        Button editBtn = new Button("Edit");
        editBtn.setStyle("-fx-background-color: #495DA3; -fx-text-fill: white;");

        Button hapusBtn = new Button("Delete");
        hapusBtn.setStyle("-fx-background-color: #E53935; -fx-text-fill: white;");

        HBox tombolBox = new HBox(10, kota, editBtn, hapusBtn);
        tombolBox.setAlignment(Pos.CENTER_RIGHT);

        card.getChildren().addAll(nama, email, nomor, tombolBox);

        return card;
    }

}
