package com.example.otodu.Controller;

import com.example.otodu.Utils.UbahHalaman;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

public class NLPDashboardController {
    @FXML private Label mentorLabel;

    @FXML
    public void initialize(){
        mentorLabel.setOnMouseClicked(e -> {
            UbahHalaman.switchScene(e, "CariMentor.fxml");
        });
    }
}
