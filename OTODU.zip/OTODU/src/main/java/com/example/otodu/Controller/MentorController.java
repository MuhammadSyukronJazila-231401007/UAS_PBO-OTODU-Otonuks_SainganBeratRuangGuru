package com.example.otodu.Controller;

import com.example.otodu.MainApplication;
import com.example.otodu.Model.Mentor;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MentorController {
    @FXML
    private VBox mentorContainer;
    private List<Mentor> semuaMentor = new ArrayList<>();

    public void tampilkanSemuaMentor() {
        mentorContainer.getChildren().clear();
        for (Mentor mentor : semuaMentor) {
            mentorContainer.getChildren().add(buatCard(mentor));
        }
    }

    @FXML
    public void initialize() {
        semuaMentor = List.of(
                new Mentor(1, "a@mail.com", "Andi", "08123456", "Bandung", "pass", "Mentor", 10),
                new Mentor(2, "b@mail.com", "Budi", "08123457", "Jakarta", "pass", "Mentor", 20)
        );
        semuaMentor = new ArrayList<>(semuaMentor); // ubah jadi mutable
        tampilkanSemuaMentor();
    }


    private HBox buatCard(Mentor mentor) {
        HBox card = new HBox(15);
        card.setAlignment(Pos.CENTER_LEFT);
        card.setStyle("-fx-background-color: white; -fx-padding: 15; -fx-border-color: #E0E0E0; -fx-border-width: 0 0 1 0;");

        // Bagian kiri: Nama, Email, Nomor
        VBox detailBox = new VBox(4);

        Label namaLabel = new Label(mentor.getNama());
        namaLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #495DA3;");

        Label emailLabel = new Label(mentor.getEmail());
        emailLabel.setStyle("-fx-font-size: 13px;");

        Label nomorLabel = new Label(mentor.getNomor());
        nomorLabel.setStyle("-fx-font-size: 13px;");

        detailBox.getChildren().addAll(namaLabel, emailLabel, nomorLabel);

        // Spacer
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Bagian kanan: Kota (badge), Edit, Delete
        HBox actionBox = new HBox(10);

        Label kotaLabel = new Label(mentor.getKota());
        kotaLabel.setStyle("-fx-background-color: #E1F0FF; -fx-border-color: #007BFF; -fx-padding: 4 10 4 10; -fx-font-size: 12px;");

        Button editButton = new Button("Edit");
        editButton.setStyle("-fx-background-color: #495DA3; -fx-text-fill: white;");
        editButton.setOnAction(e -> {
            // Edit mentor: tampilkan dialog atau log ke console
            System.out.println("Edit mentor: " + mentor.getNama());
        });

        Button deleteButton = new Button("Delete");
        deleteButton.setStyle("-fx-background-color: #E53935; -fx-text-fill: white;");
        deleteButton.setOnAction(e -> {
            semuaMentor.remove(mentor);
            tampilkanSemuaMentor(); // fungsi untuk refresh ulang daftar
        });

        actionBox.getChildren().addAll(kotaLabel, editButton, deleteButton);

        // Gabungkan ke card
        card.getChildren().addAll(detailBox, spacer, actionBox);
        return card;
    }

}
